﻿using System;
using System.Linq;
using System.Drawing;
using System.IO;

namespace Harvester_image_ui
{
    class HarvesterImageConverter
    {
        public static void ConvertImage(string bmFileLocation, string paletteLocation, string saveLocation)
        {
            var imageBytes = System.IO.File.ReadAllBytes(bmFileLocation);
            var palleteBytes = System.IO.File.ReadAllBytes(paletteLocation);

            int currentByteLocation = 0;

            var width = BitConverter.ToUInt32(imageBytes.Take(4).ToArray(), 0);
            currentByteLocation += 4;

            var height = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
            currentByteLocation += 4;

            //skip over the pointer to paletter file\
            currentByteLocation += 4;

            using (Bitmap bm1 = new Bitmap((int)width, (int)height))
            {
                //basically go row by row and fill in the colors
                for (int row = 0; row < height; row++)
                {
                    //go column by column
                    for (int column = 0; column < width; column++)
                    {
                        Color color;
                        int r = 0;
                        int g = 0;
                        int b = 0;

                        //get current pallete location
                        int palettelocation = (int)imageBytes[currentByteLocation];
                        //pallete is in 3s. Multiply it and then go to that location
                        palettelocation *= 3;
                        r = (int)palleteBytes[palettelocation];
                        g = (int)palleteBytes[palettelocation + 1];
                        b = (int)palleteBytes[palettelocation + 2];


                        color = Color.FromArgb(r, g, b);
                        bm1.SetPixel(column, row, color);
                        currentByteLocation++;
                    }
                }

                bm1.Save(saveLocation);
            }

            Console.WriteLine(imageBytes);
        }

        public static void ConvertAnimatedImage()
        {
            var imageBytes = System.IO.File.ReadAllBytes(@"C:\Users\crazy\Documents\Projects\Git\harvester-bm-converter\Harvester-image-ui\dev\STLRMOUS.ABM");
            var palleteBytes = System.IO.File.ReadAllBytes(@"C:\Users\crazy\Documents\Projects\Git\harvester-bm-converter\Harvester-image-ui\dev\DINER1.PAL");

            int currentByteLocation = 0;//0x00

            uint cellCount = BitConverter.ToUInt32(imageBytes.Take(4).ToArray(), 0);
            currentByteLocation += 4;// 0x04

            //I won't need this. But this is at this locaiton
            uint largestFrameByteCount = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
            currentByteLocation += 4;// 0x08

            for (int cell = 0; cell < cellCount; cell++)
            {
                //I won't need this. But this is at this locaiton
                uint cellPaddingX = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
                currentByteLocation += 4;// 0x0C
                                         //I won't need this. But this is at this locaiton
                uint cellPaddingY = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
                currentByteLocation += 4;// 0x10

                uint cellWidth = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
                currentByteLocation += 4;// 0x14
                uint cellHeight = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
                currentByteLocation += 4;// 0x18

                //check if the animation is compressed. 1 = yes, RLE. 0 = no
                byte compressed = imageBytes.Skip(currentByteLocation).FirstOrDefault();
                currentByteLocation += 1;

                uint payloadLength = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
                currentByteLocation += 4;

                //ignore this completely
                uint palettePointer = BitConverter.ToUInt32(imageBytes.Skip(currentByteLocation).Take(4).ToArray(), 0);
                currentByteLocation += 4;

                //if its compressed, exit, idk what to do lmao
                if (compressed == 0x01)
                    return;
                else
                {
                    for(int row = 0; row < cellHeight; row++)
                    {
                        for (int col = 0; col < cellWidth; col++)
                        {

                        }
                    }



                }
            }
        }



        public static void FindUncompressed()
        {
            FileInfo[] bmFiles = new DirectoryInfo(@"C:\Users\crazy\Desktop\Harvester\Extracted\Disc1\GRAPHIC\ROOMANIM").GetFiles().Where(x => x.Name.ToUpper().EndsWith(".ABM")).ToArray();


            //go through each bm file. Try to find a .PAL file to match it
            foreach (var bmFile in bmFiles)
            {
                byte[] test = File.ReadAllBytes(bmFile.FullName);
                byte test2 = test[24];
                if (test2 != 0x01)
                    Console.WriteLine(bmFile.Name);
            }
        }

        /**
         *  Every ABM file begins with an 8-byte global header:
            
            0x00 u32 - Total number of cells
            0x04 u32 - Largest Frame Bytecount (the largest result of cell_width*cell_height in the sequence, for allocating arrays)
            
            A local header for the first cell follows:
            
            0x08 u32 - Cell padding on the X-axis from 0 // Can skip if simply extracting cells and not drawing to screen
            0x0C u32 - Cell padding on the Y-axis from 0 // Can skip if simply extracting cells and not drawing to screen
            0x10 u32 - Cell width
            0x14 u32 - Cell height
            0x18 u8  - Compression flag (0 = uncompressed, 1 = RLE)
            0x19 u32 - Payload length in bytes
            0x1D u32 - Unknown (presumed to be a pointer to an external palette file)
            
            The image payload then follows based on the payload length.
            
            If the file is uncompressed, each byte represents one pixel similar to the BM file format above.
            If the file is compressed with RLE, the formula is as follows:
            
            READ a control byte.
              IF the top bit is 0, the following X bytes are literal based on the lower 7 bits of the control byte.
              ELSE the top bit is 1, the following byte is repeated X number of times based on the lower 7 bits of the control byte.
            DO until end of payload.
            
            Once the image is written, repeat the above steps (local header + payload data) for each cell.
         */
    }
}
